
extern zend_class_entry *phalcon_logger_exception_ce;

ZEPHIR_INIT_CLASS(Phalcon_Logger_Exception);

